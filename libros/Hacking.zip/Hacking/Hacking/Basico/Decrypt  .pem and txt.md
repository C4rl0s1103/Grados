
--------------------------

---------------------------------

- Podemos desencriptar una archivo pem si tenemos un txt de la siguiente forma.

```bash
openssl pkeyutl -decrypt -inkey private_key.pem -in private.txt -out decrypted_file.txt
```

![[Pasted image 20240526173531.png]]