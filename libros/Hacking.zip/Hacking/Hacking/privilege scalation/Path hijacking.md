
------------------

--------------

 - He podido observar que el archivo backup ejecuta el comando tar sin estar su ruta absoluta por lo que me voy a crear un archivo tar en tmp el cual voy a exportar su ruta al path, para que cuando backup llame a tar use el que yo he creado y le pase un comando malicioso con el que poder escalar mis privilegios.

![[Pasted image 20240601030602.png]]