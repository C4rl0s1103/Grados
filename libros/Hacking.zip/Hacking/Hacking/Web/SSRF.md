
------------------

---------------------

- Cuando nosostros realizamos un escaneo de nmap puede que veamos el puerto 80 abierto, pero alomejor tambien esta corriendo un puerto 8080 internamente que nosotros desde fuera no podemos llegar a ver, debido a alguna regla de firewall.
- 







# Falsificación de solicitudes del lado del servidor (SSRF)

En esta sección, explicamos qué es la falsificación de solicitudes del lado del servidor (SSRF) y describimos algunos ejemplos comunes. También le mostramos cómo encontrar y explotar las vulnerabilidades de la SSRF.

## ¿Qué es la SSRF?

La falsificación de solicitudes del lado del servidor es una vulnerabilidad de seguridad web que permite a un atacante hacer que la aplicación del lado del servidor realice solicitudes a una ubicación no deseada.

En un ataque SSRF típico, el atacante puede hacer que el servidor establezca una conexión solo con servicios internos dentro de la infraestructura de la organización. En otros casos, pueden obligar al servidor a conectarse a sistemas externos arbitrarios. Esto podría filtrar datos confidenciales, como credenciales de autorización.

## ¿Cuál es el impacto de los ataques de la SSRF?

Un ataque SSRF exitoso a menudo puede resultar en acciones no autorizadas o acceso a datos dentro de la organización. Esto puede estar en la aplicación vulnerable o en otros sistemas back-end con los que la aplicación puede comunicarse. En algunas situaciones, la vulnerabilidad SSRF podría permitir a un atacante realizar la ejecución de comandos arbitrarios.

Un exploit SSRF que provoque conexiones a sistemas externos de terceros podría dar lugar a ataques maliciosos hacia adelante. Puede parecer que se originan en la organización que hospeda la aplicación vulnerable.

## Ataques comunes de la SSRF

Los ataques SSRF a menudo explotan las relaciones de confianza para escalar un ataque desde la aplicación vulnerable y realizar acciones no autorizadas. Estas relaciones de confianza pueden existir en relación con el servidor o en relación con otros sistemas back-end dentro de la misma organización.

### Ataques SSRF contra el servidor

En un ataque SSRF contra el servidor, el atacante hace que la aplicación realice una solicitud HTTP al servidor que aloja la aplicación, a través de su interfaz de red de bucle invertido. Por lo general, esto implica proporcionar una dirección URL con un nombre de host como (una dirección IP reservada que apunta al adaptador de bucle invertido) o (un nombre de uso común para el mismo adaptador). `127.0.0.1``localhost`

Por ejemplo, imagine una aplicación de compras que permite al usuario ver si un artículo está en stock en una tienda en particular. Para proporcionar la información de existencias, la aplicación debe consultar varias API de REST de back-end. Para ello, pasa la dirección URL al punto de conexión de la API de back-end correspondiente a través de una solicitud HTTP de front-end. Cuando un usuario ve el estado de las existencias de un artículo, su navegador realiza la siguiente solicitud:

```url
POST /product/stock HTTP/1.0 Content-Type: application/x-www-form-urlencoded Content-Length: 118 stockApi=http://stock.weliketoshop.net:8080/product/stock/check%3FproductId%3D6%26storeId%3D1
```

Esto hace que el servidor realice una solicitud a la dirección URL especificada, recupere el estado de las existencias y lo devuelva al usuario.

En este ejemplo, un atacante puede modificar la solicitud para especificar una dirección URL local para el servidor:

`POST /product/stock HTTP/1.0 Content-Type: application/x-www-form-urlencoded Content-Length: 118 stockApi=http://localhost/admin`

El servidor obtiene el contenido de la URL y se lo devuelve al usuario. `/admin`

Un atacante puede visitar la dirección URL, pero normalmente solo pueden acceder a la funcionalidad administrativa los usuarios autenticados. Esto significa que un atacante no verá nada de interés. Sin embargo, si la solicitud a la dirección URL proviene del equipo local, se omiten los [controles de acceso](https://portswigger.net/web-security/access-control) normales. La aplicación concede acceso completo a la funcionalidad administrativa, ya que la solicitud parece originarse en una ubicación de confianza. `/admin``/admin`