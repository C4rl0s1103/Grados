
-------------
#activeDirectory #windows 

---------------

- Ver información sobre como están estructurados los binarios y programados