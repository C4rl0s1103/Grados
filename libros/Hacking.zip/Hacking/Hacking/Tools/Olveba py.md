
------------
#excel 

---------------

Herramienta para leer informacion en un excel

`olevba contabilidad.xlsm --decode --reveal --detailed --deobf`