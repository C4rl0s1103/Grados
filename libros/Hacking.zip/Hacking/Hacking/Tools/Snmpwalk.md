-------------------
#snmp #udp

----------

- Lo podemos utilizar para enumerar el puerto snmp de la siguiente manera.
- Podemos usar para ir mas rapido de la misa forma snmpbulkwalk

```
snmpbulkwalk -c [COMM_STRING] -v [VERSION] [IP] . #Don't forget the final dot
snmpbulkwalk -c public -v2c 10.10.11.136 .

snmpwalk -v [VERSION_SNMP] -c [COMM_STRING] [DIR_IP]
snmpwalk -v [VERSION_SNMP] -c [COMM_STRING] [DIR_IP] 1.3.6.1.2.1.4.34.1.3 #Get IPv6, needed dec2hex
snmpwalk -v [VERSION_SNMP] -c [COMM_STRING] [DIR_IP] NET-SNMP-EXTEND-MIB::nsExtendObjects #get extended
snmpwalk -v [VERSION_SNMP] -c [COMM_STRING] [DIR_IP] .1 #Enum all

snmp-check [DIR_IP] -p [PORT] -c [COMM_STRING]

nmap --script "snmp* and not snmp-brute" <target>

braa <community string>@<IP>:.1.3.6.* #Bruteforce specific OID
```

![[Pasted image 20240601010413.png]]