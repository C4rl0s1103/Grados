
--------------
#telnet #metasploitable

--------------------


- Tenemos el puerto 23 con el servicio telnet activado por lo que decido realizar fuerza bruta con un script que tiene nmap. Y consigo las credenciales para poder logearme en el servicio.
![[Pasted image 20240512194409.png]]

- Con esas credenciales consigo logearmne en el servivio telnet desde consola y consigo acceso a la maquina.
 ![[Pasted image 20240512194457.png]]