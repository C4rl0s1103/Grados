
----------


-----------
![[Pasted image 20240512193005.png]]


- Puerto 21 abierto con el usuario anonymous habilitado, y te permite que accedas a ver informacion compartida y llegar a descargarla.


![[Pasted image 20240512193014.png]]

- Encontramos una versión del servicio ftp 2.3.4 que esta desactualizada con la que si buscamos desde searchsploit vemos que tiene una vulnerabilidad explotable mediante un script o metasploit, que te permite acceder al sistema como usuario root  mediante un backdoor. El nombre del cve que se explota es el siguiente  CVE-2011-2523

![[Pasted image 20240512193035.png]]