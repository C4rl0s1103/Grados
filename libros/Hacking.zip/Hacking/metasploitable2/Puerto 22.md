




- Tenemos un puerto 22 con el servicio ssh corriendo que tiene una version muy desactualizada, que nos permite utilizar una vulneravilidad de enumeracion de usuarios la cual nos va a permitir enumerar usuarios validos en el sistema. El cve de la vulneravilidad seria el siguiente. 
  CVE-2018-15473

- Mediante un script conseguimos obtener un usuario valido en el sistema -> msfadmin
![[Pasted image 20240512193106.png]]

- Gracias al puerto 22 y a que tenemos un posible usuario pudimos llegar a obtener la contraseña de este usuario mediante el uso de la herramienta hydra. 