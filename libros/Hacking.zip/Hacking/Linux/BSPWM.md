

- Dependencias

- **apt install build-essential git vim xcb libxcb-util0-dev libxcb-ewmh-dev libxcb-randr0-dev libxcb-icccm4-dev libxcb-keysyms1-dev libxcb-xinerama0-dev libasound2-dev libxcb-xtest0-dev libxcb-shape0-dev**

- **git clone https://github.com/baskerville/bspwm.git**

make 
sudo make install

- **git clone https://github.com/baskerville/sxhkd.git**

make
sudo make install

Para instalar cada uno de estos, lo que debéis hacer es meteros en ambos directorios por separado y ejecutar los comandos ‘**make**‘ y ‘**sudo make install**‘.

A continuación tenéis el enlace al archivo de configuración ‘**bspwm_resize**‘ que usamos al final de esta clase:

- [Archivo bspwm_resize](https://hack4u.io/wp-content/uploads/2022/09/bspwm_resize.txt)

- Creamos los siguientes directorios
mkdir ~/.config/{bspwm,sxhkd}

- Añadimos los siguientes comandos. ![[Pasted image 20240718225622.png]]



bspwm resize

 ```bash
 #!/usr/bin/env dash

if bspc query -N -n focused.floating > /dev/null; then
	step=20
else
	step=100
fi

case "$1" in
	west) dir=right; falldir=left; x="-$step"; y=0;;
	east) dir=right; falldir=left; x="$step"; y=0;;
	north) dir=top; falldir=bottom; x=0; y="-$step";;
	south) dir=top; falldir=bottom; x=0; y="$step";;
esac

bspc node -z "$dir" "$x" "$y" || bspc node -z "$falldir" "$x" "$y"
```

vidireccional en vmware

![[Pasted image 20240719000848.png]]