
---------------
#htb #activeDirectory 

------------

- Realizamos un escaneo de nmap.
![[Pasted image 20240530135019.png]]

- Utilizamos smbmap para ver archivos compartidos en el sistema pasandole una null session.
![[Pasted image 20240530135147.png]]

- Con el uso de crackmapecxec podemos ver que estamos ante un DC y su nombre.
![[Pasted image 20240530135442.png]]

- Nos encontramos un archivo que nos llama la atencion despues de habernos conectado mediante smbclient a la maquina por lo que procedemos a descargarlo. ![[Pasted image 20240530135956.png]]

- En el binario que obtuvimos por smb vimos la posibilidad de que ldap fuese un niombre de usuario por lo que utilizamos la herramienta kerbrute, para que via kerberos pudiesemos listar el usuario ya que tambien vimos que teniamos el puerto 88 habilitado. Y vimos que era valido ![[Pasted image 20240530140903.png]]

