
------------------
#kerberos #activeDirectory #windows 

------------

- TGT -> Ticket Granting Ticket: Que es el ticket que es presentado al KDC para obtener el TGS
- TGS -> Ticket Granting Service: Es el ticket que es presentado a cuyos recursos nos queremos conectar.
- KDC -> Key Distribution Center: Es el servicio de kerberos encargado de distribuir los tickets a los usuarios normalmente esta instalado en el DC
- AP -> Application Server: Servicio que ofrecen los recursos a los que nos que nos queremos conectar

------------------------------------

- La función normal de Kerberos es cuando el usuario introduce la contraseña, y esta ultima se convierte en un hash NTLM que se envía al KDC ; A este proceso se le llama -> AS-REQ. 
- En este proceso lo que tratas es de solicitar un TGT al KDC, después de que el KDC realice una serie de validaciones, te devuelve un TGT que esta cifrado y firmado; A este proceso se le conoce como AS-REP
- Una vez has obtenido devuelta este TGT, tu como usuario lo que tratas de solicitar un TGS que se cifra con el hash NTLM del servicio, a esto se le llama TGS-REQ
- Después de hacer una serie de validaciones el KDC nos devolvería un TGS, y a esto se le llama TGS-REP.
- Una vez obtenido ese TGS, se lo enviamos al AP, a lo que se le conoce como AP-REQ.
- Y si todo ha funcionado de manera correcta el AP nos deberia de responder con un AP-REP
 ![[Captura de pantalla 2024-05-31 025821.png]]

-----------------------

- Gracias a todo esto que acabamos de ver podriamos llegar a efectuar un 
`Silver Ticket Attack` -> Pretende enviar un TGS al servido para que este nos reponda y gracias a eso poder llegar a acceder a los recursos del sistema

- `Golden Ticket Attack` -> Se centra en generar un TGT que es presenta al KDC para obtener un TGS.

- **Para generar un TGS** necesitaremos 3 valores -> Un hash NTLM del servicio correspondiente, Domain SID (getPac.py) y el SPN, con estos tres valores podemos tratar de generar un TGS. Este TGS puedes generarlo desde el usuario que nosotros queramos, para tratar de conectarte directamente al AP y tratar de sonseguir directamente un AP-REP.