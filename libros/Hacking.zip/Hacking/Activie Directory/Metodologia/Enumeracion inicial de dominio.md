
--------------


---------


#### Puntos de datos clave

|**Punto de datos**|**Descripción**|
|---|---|
|`AD Users`|Estamos tratando de enumerar las cuentas de usuario válidas a las que podemos dirigirnos para la pulverización de contraseñas.|
|`AD Joined Computers`|Los equipos clave incluyen controladores de dominio, servidores de archivos, servidores SQL, servidores web, servidores de correo de Exchange, servidores de bases de datos, etc.|
|`Key Services`|Kerberos, NetBIOS, LDAP, DNS|
|`Vulnerable Hosts and Services`|Cualquier cosa que pueda ser una victoria rápida. (también conocido como un host fácil de explotar y afianzarse)|


## TTPs

Enumerar un entorno de AD puede ser abrumador si se aborda sin un plan. Hay una gran cantidad de datos almacenados en AD, y puede llevar mucho tiempo tamizarlos si no se miran en etapas progresivas, y es probable que nos perdamos cosas. Tenemos que establecer un plan de juego para nosotros mismos y abordarlo pieza por pieza. Todos trabajamos de maneras ligeramente diferentes, por lo que a medida que ganemos más experiencia, comenzaremos a desarrollar nuestra propia metodología repetible que funcione mejor para nosotros. Independientemente de cómo procedamos, normalmente comenzamos en el mismo lugar y buscamos los mismos puntos de datos. Experimentaremos con muchas herramientas en esta sección y en las siguientes. Es importante reproducir todos los ejemplos e incluso intentar recrear ejemplos con diferentes herramientas para ver cómo funcionan de manera diferente, aprender su sintaxis y encontrar qué enfoque funciona mejor para nosotros.

Comenzaremos con la identificación de los hosts de la red, seguidos de la validación de los resultados para obtener más información sobre cada host (qué servicios se están ejecutando, nombres, posibles vulnerabilidades, etc.). Una vez que sabemos qué hosts existen, podemos proceder a sondear esos hosts, buscando cualquier dato interesante que podamos obtener de ellos. Una vez que hayamos realizado estas tareas, debemos detenernos y reagruparnos y mirar qué información tenemos. En este momento, es de esperar que tengamos un conjunto de credenciales o una cuenta de usuario a la que apuntar para un punto de apoyo en un host unido a un dominio o que tengamos la capacidad de comenzar la enumeración de credenciales desde nuestro host de ataque de Linux.`passive``active`

Veamos algunas herramientas y técnicas que nos ayudarán con esta enumeración.


### Identificación de hosts

Primero, tomemos un tiempo para escuchar la red y ver qué está pasando. Podemos usar y para "poner nuestro oído en el cable" y ver qué hosts y tipos de tráfico de red podemos capturar. Esto es particularmente útil si el enfoque de evaluación es de "caja negra". Notamos algunas solicitudes y respuestas [ARP](https://en.wikipedia.org/wiki/Address_Resolution_Protocol), [MDNS](https://en.wikipedia.org/wiki/Multicast_DNS) y otros paquetes básicos de [capa dos](https://www.juniper.net/documentation/us/en/software/junos/multicast-l2/topics/topic-map/layer-2-understanding.html) (dado que estamos en una red conmutada, estamos limitados al dominio de difusión actual), algunos de los cuales podemos ver a continuación. Este es un gran comienzo que nos da algunos bits de información sobre la configuración de la red del cliente.`Wireshark``TCPDump`

Desplácese hasta la parte inferior, genere el objetivo, conéctese al host de ataque de Linux usando y encienda Wireshark para comenzar a capturar tráfico.`xfreerdp`

#### Inicie Wireshark en ea-attack01

  Enumeración inicial del dominio

```shell-session
┌─[htb-student@ea-attack01]─[~]
└──╼ $sudo -E wireshark

11:28:20.487     Main Warn QStandardPaths: runtime directory '/run/user/1001' is not owned by UID 0, but a directory permissions 0700 owned by UID 1001 GID 1002
<SNIP>
```

#### Salida de Wireshark

![imagen](https://academy.hackthebox.com/storage/modules/143/ea-wireshark.png)

- Los paquetes ARP nos hacen conscientes de los hosts: 172.16.5.5, 172.16.5.25, 172.16.5.50, 172.16.5.100 y 172.16.5.125.

  

![imagen](https://academy.hackthebox.com/storage/modules/143/ea-wireshark-mdns.png)

- MDNS nos informa sobre el host ACADEMY-EA-WEB01.

  

Si estamos en un host sin una GUI (lo cual es típico), podemos usar [tcpdump](https://linux.die.net/man/8/tcpdump), [net-creds](https://github.com/DanMcInerney/net-creds) y [NetMiner](https://www.netminer.com/en/product/netminer.php), etc., para realizar las mismas funciones. También podemos usar tcpdump para guardar una captura en un archivo .pcap, transferirla a otro host y abrirla en Wireshark.

#### Salida de tcpdump

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ sudo tcpdump -i ens224 
```


Nuestro primer vistazo al tráfico de red nos llevó a un par de hosts a través de y . Ahora vamos a utilizar una herramienta llamada para analizar el tráfico de la red y determinar si aparece algo más en el dominio.`MDNS``ARP``Responder`

[Responder](https://github.com/lgandx/Responder-Windows) es una herramienta creada para escuchar, analizar y envenenar , y solicitudes y respuestas. Tiene muchas más funciones, pero por ahora, todo lo que estamos utilizando es la herramienta en su modo Analizar. Esto escuchará pasivamente a la red y no enviará ningún paquete envenenado. Cubriremos esta herramienta más en profundidad en secciones posteriores.`LLMNR``NBT-NS``MDNS`

#### Iniciando el respondedor

Código: bash

```bash
sudo responder -I ens224 -A 
```

A medida que iniciamos Responder con el modo de análisis pasivo habilitado, veremos que las solicitudes fluyen en nuestra sesión. Observe a continuación que encontramos algunos hosts únicos que no se mencionaron anteriormente en nuestras capturas de Wireshark. Vale la pena anotarlos a continuación, ya que estamos comenzando a construir una buena lista de objetivos de IP y nombres de host DNS.

Nuestras comprobaciones pasivas nos han dado algunos hosts para anotar para una enumeración más profunda. Ahora vamos a realizar algunas comprobaciones activas, comenzando con un barrido ICMP rápido de la subred usando .`fping`

[Fping](https://fping.org/) nos proporciona una capacidad similar a la de la aplicación de ping estándar en el sentido de que utiliza solicitudes y respuestas ICMP para comunicarse e interactuar con un host. Donde fping brilla es en su capacidad para emitir paquetes ICMP contra una lista de múltiples hosts a la vez y su capacidad de scripts. Además, funciona de forma rotatoria, consultando a los hosts de forma cíclica en lugar de esperar a que vuelvan varias solicitudes a un solo host antes de continuar. Estas comprobaciones nos ayudarán a determinar si hay algo más activo en la red interna. ICMP no es una ventanilla única, pero es una manera fácil de tener una idea inicial de lo que existe. Otros puertos abiertos y protocolos activos pueden apuntar a nuevos hosts para su posterior destino. Veámoslo en acción.

#### Comprobaciones activas de FPing

Aquí comenzaremos con algunas banderas: para mostrar los objetivos que están vivos, para imprimir estadísticas al final del escaneo, para generar una lista de objetivos a partir de la red CIDR y para no mostrar los resultados por objetivo.`fping``a``s``g``q`

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ fping -asgq 172.16.5.0/23

172.16.5.5
172.16.5.25
172.16.5.50
172.16.5.100
172.16.5.125
172.16.5.200
172.16.5.225
172.16.5.238
172.16.5.240

     510 targets
       9 alive
     501 unreachable
       0 unknown addresses

    2004 timeouts (waiting for response)
    2013 ICMP Echos sent
       9 ICMP Echo Replies received
    2004 other ICMP received

 0.029 ms (min round trip time)
 0.396 ms (avg round trip time)
 0.799 ms (max round trip time)
       15.366 sec (elapsed real time)
```

#### Escaneo de Nmap

Ahora que tenemos una lista de hosts activos dentro de nuestra red, podemos enumerar esos hosts aún más. Buscamos determinar qué servicios está ejecutando cada host, identificar hosts críticos como y e identificar hosts potencialmente vulnerables para sondear más adelante. Con nuestro enfoque en AD, después de hacer un amplio barrido, sería prudente que nos centráramos en los protocolos estándar que normalmente acompañan a los servicios de AD, como DNS, SMB, LDAP y Kerberos, por nombrar algunos. A continuación se muestra un ejemplo rápido de un simple escaneo de Nmap.`Domain Controllers``web servers`

Código: bash

```bash
sudo nmap -v -A -iL hosts.txt -oN /home/htb-student/Documents/host-enum
```