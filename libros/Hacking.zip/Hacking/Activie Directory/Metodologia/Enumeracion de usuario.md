
----------

-----------


## KERBRUTE
## Identificación de los usuarios

Si nuestro cliente no nos proporciona un usuario con el que empezar a probar (lo que suele ser el caso), tendremos que encontrar una manera de establecer un punto de apoyo en el dominio, ya sea obteniendo credenciales de texto sin cifrar o un hash de contraseña NTLM para un usuario, un shell SYSTEM en un host unido a un dominio o un shell en el contexto de una cuenta de usuario de dominio. Obtener un usuario válido con credenciales es fundamental en las primeras etapas de una prueba de penetración interna. Este acceso (incluso en el nivel más bajo) abre muchas oportunidades para realizar enumeraciones e incluso ataques. Veamos una forma en que podemos comenzar a recopilar una lista de usuarios válidos en un dominio para usarla más adelante en nuestra evaluación.

### Kerbrute: enumeración interna de nombres de usuario de AD

[Kerbrute](https://github.com/ropnop/kerbrute) puede ser una opción más sigilosa para la enumeración de cuentas de dominio. Aprovecha el hecho de que los errores de autenticación previa de Kerberos a menudo no desencadenarán registros ni alertas. Usaremos Kerbrute junto con las listas de usuarios de [Insidetrust](https://github.com/insidetrust/statistically-likely-usernames). Este repositorio contiene muchas listas de usuarios diferentes que pueden ser extremadamente útiles cuando se intenta enumerar usuarios cuando se comienza desde una perspectiva no autenticada. Podemos apuntar a Kerbrute a la CD que encontramos antes y alimentarla con una lista de palabras. La herramienta es rápida y se nos proporcionarán resultados que nos permitirán saber si las cuentas encontradas son válidas o no, lo cual es un excelente punto de partida para lanzar ataques como la pulverización de contraseñas, que cubriremos en profundidad más adelante en este módulo.`jsmith.txt``jsmith2.txt`

Para comenzar con Kerbrute, podemos descargar [binarios precompilados](https://github.com/ropnop/kerbrute/releases/latest) para la herramienta para realizar pruebas desde Linux, Windows y Mac, o podemos compilarlo nosotros mismos. Por lo general, esta es la mejor práctica para cualquier herramienta que introduzcamos en un entorno de cliente. Para compilar los binarios que se usarán en el sistema de nuestra elección, primero clonamos el repositorio:

#### Clonación del repositorio de GitHub de Kerbrute

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ sudo git clone https://github.com/ropnop/kerbrute.git

Cloning into 'kerbrute'...
remote: Enumerating objects: 845, done.
remote: Counting objects: 100% (47/47), done.
remote: Compressing objects: 100% (36/36), done.
remote: Total 845 (delta 18), reused 28 (delta 10), pack-reused 798
Receiving objects: 100% (845/845), 419.70 KiB | 2.72 MiB/s, done.
Resolving deltas: 100% (371/371), done.
```

Escribiendo nos mostrará las opciones de compilación disponibles.`make help`

#### Opciones de compilación de listados

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ make help

help:            Show this help.
windows:  Make Windows x86 and x64 Binaries
linux:  Make Linux x86 and x64 Binaries
mac:  Make Darwin (Mac) x86 and x64 Binaries
clean:  Delete any binaries
all:  Make Windows, Linux and Mac x86/x64 Binaries
```

Podemos elegir compilar solo un binario o escribir y compilar uno para su uso en sistemas Linux, Windows y Mac (una versión x86 y x64 para cada uno).`make all`

#### Compilación para múltiples plataformas y arquitecturas

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ sudo make all

go: downloading github.com/spf13/cobra v1.1.1
go: downloading github.com/op/go-logging v0.0.0-20160315200505-970db520ece7
go: downloading github.com/ropnop/gokrb5/v8 v8.0.0-20201111231119-729746023c02
go: downloading github.com/spf13/pflag v1.0.5
go: downloading github.com/jcmturner/gofork v1.0.0
go: downloading github.com/hashicorp/go-uuid v1.0.2
go: downloading golang.org/x/crypto v0.0.0-20201016220609-9e8e0b390897
go: downloading github.com/jcmturner/rpc/v2 v2.0.2
go: downloading github.com/jcmturner/dnsutils/v2 v2.0.0
go: downloading github.com/jcmturner/aescts/v2 v2.0.0
go: downloading golang.org/x/net v0.0.0-20200114155413-6afb5195e5aa
cd /tmp/kerbrute
rm -f kerbrute kerbrute.exe kerbrute kerbrute.exe kerbrute.test kerbrute.test.exe kerbrute.test kerbrute.test.exe main main.exe
rm -f /root/go/bin/kerbrute
Done.
Building for windows amd64..

<SNIP>
```

El directorio recién creado contendrá nuestros binarios compilados.`dist`

#### Listado de los binarios compilados en dist

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ ls dist/

kerbrute_darwin_amd64  kerbrute_linux_386  kerbrute_linux_amd64  kerbrute_windows_386.exe  kerbrute_windows_amd64.exe
```

A continuación, podemos probar el binario para asegurarnos de que funciona correctamente. Usaremos la versión x64 en el host de ataque Parrot Linux suministrado en el entorno de destino.

#### Probar el binario kerbrute_linux_amd64

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ ./kerbrute_linux_amd64 

    __             __               __     
   / /_____  _____/ /_  _______  __/ /____ 
  / //_/ _ \/ ___/ __ \/ ___/ / / / __/ _ \
 / ,< /  __/ /  / /_/ / /  / /_/ / /_/  __/
/_/|_|\___/_/  /_.___/_/   \__,_/\__/\___/                                        

Version: dev (9cfb81e) - 02/17/22 - Ronnie Flathers @ropnop

This tool is designed to assist in quickly bruteforcing valid Active Directory accounts through Kerberos Pre-Authentication.
It is designed to be used on an internal Windows domain with access to one of the Domain Controllers.
Warning: failed Kerberos Pre-Auth counts as a failed login and WILL lock out accounts

Usage:
  kerbrute [command]
  
  <SNIP>
```

Podemos agregar la herramienta a nuestro PATH para que sea fácilmente accesible desde cualquier lugar del host.

#### Añadiendo la herramienta a nuestra ruta

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ echo $PATH
/home/htb-student/.local/bin:/snap/bin:/usr/sandbox/:/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/usr/share/games:/usr/local/sbin:/usr/sbin:/sbin:/snap/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/home/htb-student/.dotnet/tools
```

#### Mover el binario

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ sudo mv kerbrute_linux_amd64 /usr/local/bin/kerbrute
```

#### Enumeración de usuarios con Kerbrute

  Enumeración inicial del dominio

```shell-session
zunderrubb@htb[/htb]$ kerbrute userenum -d INLANEFREIGHT.LOCAL --dc 172.16.5.5 jsmith.txt -o valid_ad_users

2021/11/17 23:01:46 >  Using KDC(s):
2021/11/17 23:01:46 >   172.16.5.5:88
2021/11/17 23:01:46 >  [+] VALID USERNAME:       jjones@INLANEFREIGHT.LOCAL
2021/11/17 23:01:46 >  [+] VALID USERNAME:       sbrown@INLANEFREIGHT.LOCAL
2021/11/17 23:01:46 >  [+] VALID USERNAME:       tjohnson@INLANEFREIGHT.LOCAL
2021/11/17 23:01:50 >  [+] VALID USERNAME:       evalentin@INLANEFREIGHT.LOCAL

 <SNIP>
 
2021/11/17 23:01:51 >  [+] VALID USERNAME:       sgage@INLANEFREIGHT.LOCAL
2021/11/17 23:01:51 >  [+] VALID USERNAME:       jshay@INLANEFREIGHT.LOCAL
2021/11/17 23:01:51 >  [+] VALID USERNAME:       jhermann@INLANEFREIGHT.LOCAL
2021/11/17 23:01:51 >  [+] VALID USERNAME:       whouse@INLANEFREIGHT.LOCAL
2021/11/17 23:01:51 >  [+] VALID USERNAME:       emercer@INLANEFREIGHT.LOCAL
2021/11/17 23:01:52 >  [+] VALID USERNAME:       wshepherd@INLANEFREIGHT.LOCAL
2021/11/17 23:01:56 >  Done! Tested 48705 usernames (56 valid) in 9.940 seconds
```

Podemos ver en nuestra salida que validamos 56 usuarios en INLANEFREIGHT. LOCAL y solo tardó unos segundos en hacerlo. Ahora podemos tomar estos resultados y crear una lista para su uso en ataques de pulverización de contraseñas dirigidos.'