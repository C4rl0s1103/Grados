
-----------

----------

- Para enumerar ldap tenemos varias opciones y lo mejor que podemos hacer si no sabemos como podemos hacerlo seria checkear en hacktricks ya que viene todo perfectamente contemplado.
- Podriamos probar con ldap search para enumerarlo todo y podemos probar sin credenciales pero si tenemos credenciales podriamos pobrar con estos comandos:

```bash
ldapsearch -x -H ldap://10.10.11.174 -D 'ldap@support.htb' -w 'nvEfEK16^1aM4$e7AclUf8x$tRWxPWO1%lmz' -b "DC=support,DC=htb"
```
![[Pasted image 20240723122701.png]]


