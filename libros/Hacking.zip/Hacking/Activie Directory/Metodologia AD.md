
----------------


----------------

- nmap

- Enumeration smb

- Enumeration DNS

- Enumeration Ldap

- Enumeration rpc

- Enumeration kerberos (kerbrute)

- 