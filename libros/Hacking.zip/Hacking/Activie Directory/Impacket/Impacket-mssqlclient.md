
-------------------
#activeDirectory #impacket 

-----------------

- Lo usaremos cuando estemos ante un directorio activo y tengamos habilitado la base de datos de mysql, eso si, es necesario tener al menos un usuario y una credencial valida en el sistema para poder usarlo.

- El comando principal para usar esta herramienta seria el siguiente 
```bash
impacket-mssqlclient manager.htb/operator:operator@10.10.11.236
```

- Pero puede que esto no es de un error y para indicarle que el usuario y contraseña es un usuario a nivel de sistema de windows debemos de añadirle el siguiente parámetro
```bash
impacket-mssqlclient manager.htb/operator:operator@10.10.11.236 -windows-auth
```

### Comandos principales

- xp_cmdshell "whoami" -> Si esta función esta deshabilitada podemos usar el comando enable_xp_cmdshell. 
- enum_users -> Para enumerar usuarios
- xp_dirtree -> 



