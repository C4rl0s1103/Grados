
--------------
#activeDirectory #impacket 

-----------
- Para ganar acceso al sistema cuando tengamos unas credenciales



![[Pasted image 20240423011248.png]]


![[Pasted image 20240424160135.png]]