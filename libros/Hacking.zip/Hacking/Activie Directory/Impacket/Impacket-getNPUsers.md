
----------
#activeDirectory #impacket 

--------------


- Solicitamos el ticket del usuario que no necesita autenticaacion y nos devuelve un hash ntlm de v2 que nos sireve para crackearlo


![[Pasted image 20240423005528.png]]

![[Pasted image 20240722001351.png]]