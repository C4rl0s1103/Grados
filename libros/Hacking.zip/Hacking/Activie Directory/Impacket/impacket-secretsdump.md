

Utilizamos la herramienta para ver todos los hashes de todos los usuarios que estan en el dominio.


![[Pasted image 20240423010557.png]]