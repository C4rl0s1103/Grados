
----------
#activeDirectory #windows #privilegeescalation 

-----------

Pagina web para realizar escaladas de privilegios en windows, seria el GTFOBiNS de maquinas windows.

![[Pasted image 20240602170841.png]]
