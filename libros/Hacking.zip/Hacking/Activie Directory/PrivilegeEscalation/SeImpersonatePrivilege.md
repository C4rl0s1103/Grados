
----------------------------


---------------------

Cuando accedemos a un sistema windows debemos de comprobar los privilegios que tenemos como usuario, y puede que nos encontremos con el privilegio SeImpersonatePrivilege, con el que podemos llegar a escalar privilegios de la siguiente manera .

![[Pasted image 20240720130345.png]]

Vamos a descagar en nuestra maquina host el .exe petitPotatoe y nos lo vamos a compartir con la maquina victima mediante un smbserver o si estamos con win-rm con el comando upload de manera sencilla. Y seguido con msfvenom vamos a crear una shell reversa que tambien nos vanmos a compartir con la maquina victima de la misma forma. Desde nuestra maquina host vamos a ponernos en escucha por el puerto que hayamos indicado en la shell y vamos a ejecutar los siguientes comandos.

``` powershell
./PetitPotato.exe 2 ./shell.exe
```


![[Pasted image 20240720130958.png]]
