------------

------------

Lo primero es ver que usuario somos y nuestra ip y ver toda la informacion del usuario con el comando `net user <usuario>`

![[Pasted image 20240722001957.png]]

Despues vamos a ver cales son nuestro privilegios como usuario con el comando whoami /priv 
![[Pasted image 20240722001842.png]]


- Si nos hemos encontrado con algun grupo extraño podriamos llegar a enumerar los grupos del sistema con el comando -> net group 
![[Pasted image 20240723124221.png]]


![[Pasted image 20240723125334.png]]