
- Se puede usar el comando `crackmapexec smb <rango de ip>` para poder identificar equipos potenciales en la red y asi saber donde hay que atacar.
![[Pasted image 20240422210102.png]]



