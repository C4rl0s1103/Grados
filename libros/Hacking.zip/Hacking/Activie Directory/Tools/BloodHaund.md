




- Lo primero sera 

- SharpHound.ps1: Se usa para recolectar toda la informacion de el equipo y asi poder llevartela al bloodhound


![[Pasted image 20240424204431.png]]

![[Pasted image 20240723142638.png]]

- Comando para recopilar la informacion de un sistema de directorio activo.
```
2. bloodhound-python -c All -u ' ' -p ' ' -d support.htb -ns <ip> --zip
```