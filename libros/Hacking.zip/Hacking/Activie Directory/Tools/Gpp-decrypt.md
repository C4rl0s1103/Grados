
-----------------
#FuerzaBruta 

---------------------

Descifrar la contraseña de ad en archivos xml gracias a que microsoft desvelo la forma de crackear estos hashes

