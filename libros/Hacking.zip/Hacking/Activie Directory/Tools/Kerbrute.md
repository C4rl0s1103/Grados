
-------------
#activeDirectory 

-----------

- Buscamos hacer un ataque de fuerza bruta con la herramienta para obtener credenciales validas
 - Si tenemos un usuario NOT-PREAUTH nos podemos conectar sin usar contraseña

![[Pasted image 20240423004435.png]]

![[Pasted image 20240424182601.png]]