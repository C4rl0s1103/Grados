
- Enumerar informacion del sistema una vez tenemos acceso a el