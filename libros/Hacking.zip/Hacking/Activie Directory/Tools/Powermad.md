
--------------

------------

- Nos lo descargamos con wget en el directorio de trabajo y lo compartimos con la maquina windows e introducimos los siguientes comandos.
![[Pasted image 20240723145124.png]]

