
-------------
#activeDirectory #attack 

----------------






![[Pasted image 20240426222704.png]]