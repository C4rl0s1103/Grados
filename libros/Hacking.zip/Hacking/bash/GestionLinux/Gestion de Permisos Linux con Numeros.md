
-----------
#bash

-------------

- 4 Representa todos los permisos de lectura (r)
- 2 Representa todos los permisos de lectura (w)
- 1 Representa todos los permisos de lectura (x)

---------------------

- Ahora ya podemos dar permisos sumando los numeros de los permisos que queramos dar es decir si tenemos permisos 400 estariamos dando permisos de escritura 600 serian de lectura  y 700 serian todos los permisos para el usuario. 

- Todo esto se hace sumando los numeros que hemos puesto al principio

- Si queremos ir dando permisos a los grupos y a otros simplemente tendriamos que ir donde hemos puesto un 0 modificarlo por el numero de permisos que queremos para ese apartado. 



