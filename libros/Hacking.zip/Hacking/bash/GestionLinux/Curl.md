-------
#bash #curl

-------

- `curl -o <nombre output>` -> Guarda el resultado en un archivo
- `curl -S -o /dev/null -w "%´{http_code}" ` Me dice si la web esta levantada o no
- 