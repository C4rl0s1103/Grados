---------------
#linux #bash #scripts 

---------

-  Sirve para editar archivos en linux desde la consola, podriamos poner un ejemplo de como substituir la palabra gato por la palabra perro -> `cat archivo.txt | sed 's/gato/perro/g' ` 

- Podriamos añadir al final de cada linea una frase tambien con sed -> `cat texto.txt | sed -i 's/S/ EL gato es feliz/' texto.txt  ` Con esto podemos añadir la siguiente frase al final de cada linea.

