
------------------
#bash 

------------
- sudo adduser `user` 
- deluser --remove-home `user`

