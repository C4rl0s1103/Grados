
![[Pasted image 20240421010420.png]]


Buscamos el archivo que tiene como propiedades usuario bandit7 y grupo bandi6, ademas como tamaño tiene 33bits
