
---------------------------------------------------------------------

----------------------------------------------------------------------

- -gt mayor que 

- -eq Es igual que

- -lt Menro que

-  || o una o otra sea correcta. -> `if ["$numero1" -eq "$numero2"] || 

- && esta y esta ->  `if ["$numero1" -eq "$numero2"] &&