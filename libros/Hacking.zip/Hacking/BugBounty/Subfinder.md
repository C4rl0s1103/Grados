
---------------
#bugbounty #subdominios #dns 

----------

![[Pasted image 20240530000447.png]]


```bash
subfinder -d vulnweb.com | httpx -title -status-code -tech-detect -follow-redirects
```


