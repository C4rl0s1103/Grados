
https://github.com/payloadbox/xss-payload-list/blob/master/Intruder/xss-payload-list.txt