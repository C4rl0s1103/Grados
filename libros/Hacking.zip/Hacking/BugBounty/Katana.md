
--------------

--------------

`katana -u target_url`

```
katana -u https://www.epam.com/ -c 5 -silent -o output.txt

```

